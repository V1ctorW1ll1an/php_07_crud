<?php
require_once("Perfil.php");

$perfil = new Perfil(1, 'hardware');
